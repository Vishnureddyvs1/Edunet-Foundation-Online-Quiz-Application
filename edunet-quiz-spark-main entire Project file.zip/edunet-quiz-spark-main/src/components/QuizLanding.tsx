import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import edunetLogo from "@/assets/edunet-logo.jpg";

interface QuizLandingProps {
  onStartQuiz: () => void;
  onSelectCategory: () => void;
  onViewAnalytics: () => void;
  leaderboard: Array<{ name: string; score: number; total: number; date: string }>;
}

const QuizLanding = ({ onStartQuiz, onSelectCategory, onViewAnalytics, leaderboard }: QuizLandingProps) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/20 via-background to-secondary/20 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12 quiz-fade-in">
          {/* Logo and Header */}
          <div className="flex flex-col items-center mb-6">
            <img 
              src={edunetLogo} 
              alt="Edunet Foundation Logo" 
              className="w-24 h-24 md:w-32 md:h-32 object-contain mb-4 hover:scale-105 transition-transform duration-300"
            />
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Edunet Foundation
            </h1>
          </div>
          <h2 className="text-2xl md:text-3xl font-semibold text-foreground mb-4">
            Advanced Quiz Platform
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Master technology domains with our AI-powered quiz platform. From cybersecurity to web development, 
            enhance your skills with real-time feedback and comprehensive analytics.
          </p>
          
          <div className="flex flex-wrap gap-2 justify-center items-center mb-8">
            <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
              🌐 Web Development
            </Badge>
            <Badge variant="secondary" className="bg-secondary/10 text-secondary border-secondary/20">
              🛡️ Cybersecurity
            </Badge>
            <Badge variant="secondary" className="bg-accent/10 text-accent border-accent/20">
              ⚙️ Software Engineering
            </Badge>
            <Badge variant="secondary" className="bg-success/10 text-success border-success/20">
              🤖 Data Science & AI
            </Badge>
            <Badge variant="secondary" className="bg-warning/10 text-warning border-warning/20">
              ☁️ Cloud Computing
            </Badge>
            <Badge variant="secondary" className="bg-info/10 text-info border-info/20">
              📱 Mobile Development
            </Badge>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
              <span>6 Tech Domains</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="w-2 h-2 bg-secondary rounded-full animate-pulse"></div>
              <span>Real-time Feedback</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
              <span>AI-Powered Analytics</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
              <span>Custom Quiz Creation</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-6">
            <Button 
              onClick={onSelectCategory}
              size="lg"
              className="bg-gradient-to-r from-primary to-secondary hover:from-primary-dark hover:to-secondary-dark text-white font-semibold px-8 py-4 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300 quiz-bounce"
            >
              🚀 Explore Categories
            </Button>
            <Button 
              onClick={onStartQuiz}
              size="lg"
              variant="outline"
              className="border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground font-semibold px-8 py-4 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
            >
              ⚡ Quick Start
            </Button>
          </div>

          <Button 
            onClick={onViewAnalytics}
            variant="ghost"
            className="text-muted-foreground hover:text-foreground"
          >
            📊 View Analytics Dashboard
          </Button>
        </div>

        {leaderboard.length > 0 && (
          <Card className="max-w-md mx-auto p-6 bg-card/80 backdrop-blur-sm border-primary/20 quiz-slide-in">
            <h3 className="text-xl font-semibold text-center mb-4 text-primary">
              🏆 Recent Scores
            </h3>
            <div className="space-y-3">
              {leaderboard.slice(0, 5).map((score, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <div>
                    <p className="font-medium">{score.name || 'Anonymous'}</p>
                    <p className="text-sm text-muted-foreground">{score.date}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-primary">{score.score}/{score.total}</p>
                    <p className="text-sm text-muted-foreground">
                      {Math.round((score.score / score.total) * 100)}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default QuizLanding;