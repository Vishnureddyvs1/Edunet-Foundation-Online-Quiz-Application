import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { quizCategories, QuizCategory } from "@/data/enhancedQuestions";

interface CategorySelectorProps {
  onSelectCategory: (category: QuizCategory) => void;
  onCreateCustomQuiz: () => void;
}

const CategorySelector = ({ onSelectCategory, onCreateCustomQuiz }: CategorySelectorProps) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-secondary/10 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12 quiz-fade-in">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Choose Your Domain
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Select a technology domain to test your knowledge, or create a custom quiz instantly
          </p>
          
          <Button 
            onClick={onCreateCustomQuiz}
            size="lg"
            className="bg-gradient-to-r from-accent to-secondary hover:from-accent-dark hover:to-secondary-dark text-white font-semibold px-8 py-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 mb-8"
          >
            ⚡ Create Custom Quiz Instantly
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizCategories.map((category, index) => (
            <Card 
              key={category.id}
              className="group relative overflow-hidden cursor-pointer hover:shadow-xl transition-all duration-300 quiz-slide-in bg-card/80 backdrop-blur-sm border-primary/20"
              style={{ animationDelay: `${index * 100}ms` }}
              onClick={() => onSelectCategory(category)}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-5 group-hover:opacity-10 transition-opacity duration-300`} />
              
              <div className="relative p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="text-4xl">{category.icon}</div>
                  <Badge variant="secondary" className="text-xs">
                    {category.questionCount} Questions
                  </Badge>
                </div>
                
                <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {category.name}
                </h3>
                
                <p className="text-sm text-muted-foreground mb-6 line-clamp-2">
                  {category.description}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                    <span className="text-xs text-muted-foreground">Interactive Learning</span>
                  </div>
                  
                  <div className="group-hover:translate-x-1 transition-transform duration-200">
                    <span className="text-primary font-medium">Start →</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Quick Stats */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4 text-center bg-primary/5 border-primary/20">
            <div className="text-2xl font-bold text-primary">85+</div>
            <div className="text-sm text-muted-foreground">Total Questions</div>
          </Card>
          <Card className="p-4 text-center bg-secondary/5 border-secondary/20">
            <div className="text-2xl font-bold text-secondary">6</div>
            <div className="text-sm text-muted-foreground">Tech Domains</div>
          </Card>
          <Card className="p-4 text-center bg-accent/5 border-accent/20">
            <div className="text-2xl font-bold text-accent">Real-time</div>
            <div className="text-sm text-muted-foreground">Feedback</div>
          </Card>
          <Card className="p-4 text-center bg-success/5 border-success/20">
            <div className="text-2xl font-bold text-success">AI-Powered</div>
            <div className="text-sm text-muted-foreground">Analytics</div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CategorySelector;