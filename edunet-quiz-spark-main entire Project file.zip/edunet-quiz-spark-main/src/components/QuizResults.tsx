import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { getMotivationalMessage } from "@/data/questions";

interface QuizResultsProps {
  score: number;
  totalQuestions: number;
  onRestart: () => void;
  onSaveScore: (name: string) => void;
}

const QuizResults = ({ score, totalQuestions, onRestart, onSaveScore }: QuizResultsProps) => {
  const [playerName, setPlayerName] = useState("");
  const [savedScore, setSavedScore] = useState(false);

  const percentage = Math.round((score / totalQuestions) * 100);
  const motivationalMessage = getMotivationalMessage(score, totalQuestions);

  const handleSaveScore = () => {
    if (playerName.trim()) {
      onSaveScore(playerName.trim());
      setSavedScore(true);
    }
  };

  const getGradeColor = () => {
    if (percentage >= 80) return "text-success";
    if (percentage >= 60) return "text-primary";
    return "text-error";
  };

  const getGradeBg = () => {
    if (percentage >= 80) return "from-success/20 to-success/5";
    if (percentage >= 60) return "from-primary/20 to-primary/5";
    return "from-error/20 to-error/5";
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br ${getGradeBg()} flex items-center justify-center p-4`}>
      <div className="max-w-2xl w-full">
        {/* Main Results Card */}
        <Card className="p-8 mb-6 bg-card/90 backdrop-blur-sm border-primary/20 text-center quiz-bounce">
          <div className="mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Quiz Complete! 🎉
            </h1>
            <p className="text-xl text-muted-foreground">
              {motivationalMessage}
            </p>
          </div>

          {/* Score Display */}
          <div className="mb-8">
            <div className={`text-6xl md:text-8xl font-bold ${getGradeColor()} mb-4`}>
              {percentage}%
            </div>
            <div className="text-2xl text-muted-foreground mb-6">
              You scored <span className="font-bold text-foreground">{score}</span> out of{" "}
              <span className="font-bold text-foreground">{totalQuestions}</span> questions correctly
            </div>
            
            {/* Progress Ring */}
            <div className="relative w-48 h-48 mx-auto mb-6">
              <svg className="transform -rotate-90 w-48 h-48">
                <circle
                  cx="96"
                  cy="96"
                  r="88"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="transparent"
                  className="text-muted/20"
                />
                <circle
                  cx="96"
                  cy="96"
                  r="88"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 88}`}
                  strokeDashoffset={`${2 * Math.PI * 88 * (1 - percentage / 100)}`}
                  className={percentage >= 80 ? "text-success" : percentage >= 60 ? "text-primary" : "text-error"}
                  strokeLinecap="round"
                  style={{ transition: "stroke-dashoffset 1s ease-in-out" }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className={`text-4xl font-bold ${getGradeColor()}`}>
                  {percentage}%
                </span>
              </div>
            </div>
          </div>

          {/* Performance Breakdown */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="text-center p-4 bg-success/10 rounded-lg">
              <div className="text-2xl font-bold text-success">{score}</div>
              <div className="text-sm text-muted-foreground">Correct</div>
            </div>
            <div className="text-center p-4 bg-error/10 rounded-lg">
              <div className="text-2xl font-bold text-error">{totalQuestions - score}</div>
              <div className="text-sm text-muted-foreground">Incorrect</div>
            </div>
            <div className="text-center p-4 bg-primary/10 rounded-lg">
              <div className="text-2xl font-bold text-primary">{percentage}%</div>
              <div className="text-sm text-muted-foreground">Accuracy</div>
            </div>
          </div>

          {/* Save Score Section */}
          {!savedScore && (
            <div className="mb-6 p-4 bg-muted/20 rounded-lg quiz-fade-in">
              <h3 className="text-lg font-semibold mb-3 text-foreground">
                Save your score to the leaderboard!
              </h3>
              <div className="flex gap-3 max-w-sm mx-auto">
                <Input
                  placeholder="Enter your name"
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  className="flex-1"
                  onKeyPress={(e) => e.key === 'Enter' && handleSaveScore()}
                />
                <Button 
                  onClick={handleSaveScore}
                  disabled={!playerName.trim()}
                  className="bg-secondary hover:bg-secondary-dark text-secondary-foreground"
                >
                  Save
                </Button>
              </div>
            </div>
          )}

          {savedScore && (
            <div className="mb-6 p-4 bg-success/10 rounded-lg quiz-fade-in">
              <p className="text-success font-semibold">
                ✅ Score saved successfully! Check the leaderboard on the home page.
              </p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={onRestart}
              size="lg"
              className="bg-gradient-to-r from-primary to-secondary hover:from-primary-dark hover:to-secondary-dark text-white font-semibold px-8 py-3"
            >
              Try Again 🔄
            </Button>
            <Button 
              onClick={() => window.location.reload()}
              variant="outline"
              size="lg"
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground px-8 py-3"
            >
              Back to Home 🏠
            </Button>
          </div>
        </Card>

        {/* Achievement Badge */}
        {percentage >= 90 && (
          <Card className="p-6 bg-gradient-to-r from-success/20 to-secondary/20 border-success/30 text-center quiz-slide-in">
            <div className="text-4xl mb-2">🏆</div>
            <h3 className="text-xl font-bold text-success mb-2">Excellence Achievement!</h3>
            <p className="text-success/80">You've demonstrated outstanding knowledge!</p>
          </Card>
        )}
      </div>
    </div>
  );
};

export default QuizResults;