import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Question } from "@/data/enhancedQuestions";
import { Plus, Trash2, ArrowLeft } from "lucide-react";

interface QuizCreatorProps {
  onCreateQuiz: (questions: Question[]) => void;
  onBack: () => void;
}

const QuizCreator = ({ onCreateQuiz, onBack }: QuizCreatorProps) => {
  const [quizTitle, setQuizTitle] = useState("");
  const [questions, setQuestions] = useState<Partial<Question>[]>([
    {
      question: "",
      options: ["", "", "", ""],
      correctAnswer: 0,
      explanation: "",
      difficulty: 'medium',
      tags: []
    }
  ]);

  const addQuestion = () => {
    setQuestions(prev => [...prev, {
      question: "",
      options: ["", "", "", ""],
      correctAnswer: 0,
      explanation: "",
      difficulty: 'medium',
      tags: []
    }]);
  };

  const removeQuestion = (index: number) => {
    if (questions.length > 1) {
      setQuestions(prev => prev.filter((_, i) => i !== index));
    }
  };

  const updateQuestion = (index: number, field: string, value: any) => {
    setQuestions(prev => prev.map((q, i) => 
      i === index ? { ...q, [field]: value } : q
    ));
  };

  const updateOption = (questionIndex: number, optionIndex: number, value: string) => {
    setQuestions(prev => prev.map((q, i) => 
      i === questionIndex 
        ? { ...q, options: q.options?.map((opt, oi) => oi === optionIndex ? value : opt) }
        : q
    ));
  };

  const generateQuiz = () => {
    const validQuestions = questions.filter(q => 
      q.question && 
      q.options?.every(opt => opt.trim()) && 
      q.explanation
    );

    if (validQuestions.length === 0) return;

    const formattedQuestions: Question[] = validQuestions.map((q, index) => ({
      id: Date.now() + index,
      question: q.question!,
      options: q.options!,
      correctAnswer: q.correctAnswer!,
      explanation: q.explanation!,
      category: 'custom',
      difficulty: q.difficulty!,
      tags: q.tags || []
    }));

    onCreateQuiz(formattedQuestions);
  };

  const generateAIQuestions = () => {
    // Simulate AI generation with sample questions
    const aiQuestions = [
      {
        question: "What is the key principle of responsive web design?",
        options: ["Fixed layouts", "Flexible layouts that adapt to screen size", "Only mobile-first design", "Desktop-only design"],
        correctAnswer: 1,
        explanation: "Responsive design ensures layouts adapt to different screen sizes and devices.",
        difficulty: 'medium' as const,
        tags: ['web design', 'responsive']
      },
      {
        question: "Which HTTP method is used to update existing resources?",
        options: ["GET", "POST", "PUT", "DELETE"],
        correctAnswer: 2,
        explanation: "PUT is used to update or replace existing resources on the server.",
        difficulty: 'easy' as const,
        tags: ['http', 'api']
      }
    ];

    setQuestions(aiQuestions);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-secondary/10 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" onClick={onBack} size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Create Custom Quiz</h1>
            <p className="text-muted-foreground">Build your own quiz instantly with AI assistance</p>
          </div>
        </div>

        <Card className="p-6 mb-6 bg-card/80 backdrop-blur-sm">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <Input
              placeholder="Quiz Title (optional)"
              value={quizTitle}
              onChange={(e) => setQuizTitle(e.target.value)}
              className="flex-1"
            />
            <Button onClick={generateAIQuestions} variant="outline" className="whitespace-nowrap">
              ⚡ Generate with AI
            </Button>
          </div>

          <div className="space-y-6">
            {questions.map((question, qIndex) => (
              <Card key={qIndex} className="p-4 border-primary/20">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-foreground">Question {qIndex + 1}</h3>
                  <div className="flex items-center gap-2">
                    <Select
                      value={question.difficulty}
                      onValueChange={(value) => updateQuestion(qIndex, 'difficulty', value)}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="easy">Easy</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="hard">Hard</SelectItem>
                      </SelectContent>
                    </Select>
                    {questions.length > 1 && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => removeQuestion(qIndex)}
                        className="text-error hover:bg-error/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>

                <div className="space-y-4">
                  <Textarea
                    placeholder="Enter your question"
                    value={question.question}
                    onChange={(e) => updateQuestion(qIndex, 'question', e.target.value)}
                    className="min-h-20"
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {question.options?.map((option, oIndex) => (
                      <div key={oIndex} className="flex items-center gap-2">
                        <input
                          type="radio"
                          name={`correct-${qIndex}`}
                          checked={question.correctAnswer === oIndex}
                          onChange={() => updateQuestion(qIndex, 'correctAnswer', oIndex)}
                          className="w-4 h-4 text-primary"
                        />
                        <Input
                          placeholder={`Option ${oIndex + 1}`}
                          value={option}
                          onChange={(e) => updateOption(qIndex, oIndex, e.target.value)}
                          className={question.correctAnswer === oIndex ? 'border-success' : ''}
                        />
                      </div>
                    ))}
                  </div>

                  <Textarea
                    placeholder="Explanation for the correct answer"
                    value={question.explanation}
                    onChange={(e) => updateQuestion(qIndex, 'explanation', e.target.value)}
                    className="min-h-16"
                  />
                </div>
              </Card>
            ))}
          </div>

          <div className="flex justify-between items-center mt-6">
            <Button onClick={addQuestion} variant="outline" className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add Question
            </Button>

            <div className="flex items-center gap-4">
              <Badge variant="secondary">
                {questions.filter(q => q.question && q.options?.every(opt => opt.trim()) && q.explanation).length} valid questions
              </Badge>
              <Button
                onClick={generateQuiz}
                disabled={questions.filter(q => q.question && q.options?.every(opt => opt.trim()) && q.explanation).length === 0}
                className="bg-gradient-to-r from-primary to-secondary hover:from-primary-dark hover:to-secondary-dark text-white"
              >
                Create Quiz 🚀
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default QuizCreator;