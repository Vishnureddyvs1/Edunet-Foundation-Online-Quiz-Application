import { useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { QuizAnalytics } from "@/data/enhancedQuestions";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

interface ScoreEntry {
  name: string;
  score: number;
  total: number;
  date: string;
  percentage: number;
  category?: string;
  timeSpent?: number;
}

interface AnalyticsDashboardProps {
  onClose: () => void;
}

const AnalyticsDashboard = ({ onClose }: AnalyticsDashboardProps) => {
  const [scoreHistory] = useLocalStorage<ScoreEntry[]>('edunet-quiz-leaderboard', []);

  const analytics = useMemo(() => {
    if (scoreHistory.length === 0) {
      return {
        totalQuizzes: 0,
        averageScore: 0,
        categoryPerformance: {},
        streakDays: 0,
        strongAreas: [],
        improvementAreas: [],
        recentTrend: []
      };
    }

    const totalQuizzes = scoreHistory.length;
    const averageScore = scoreHistory.reduce((sum, entry) => sum + entry.percentage, 0) / totalQuizzes;
    
    const categoryPerformance = scoreHistory.reduce((acc, entry) => {
      const category = entry.category || 'General';
      if (!acc[category]) {
        acc[category] = { attempts: 0, totalScore: 0, averageScore: 0 };
      }
      acc[category].attempts++;
      acc[category].totalScore += entry.percentage;
      acc[category].averageScore = acc[category].totalScore / acc[category].attempts;
      return acc;
    }, {} as any);

    const recentTrend = scoreHistory.slice(-7).map((entry, index) => ({
      quiz: index + 1,
      score: entry.percentage,
      date: entry.date
    }));

    const strongAreas = Object.entries(categoryPerformance)
      .filter(([_, data]: [string, any]) => data.averageScore >= 80)
      .map(([category, _]) => category);

    const improvementAreas = Object.entries(categoryPerformance)
      .filter(([_, data]: [string, any]) => data.averageScore < 70)
      .map(([category, _]) => category);

    return {
      totalQuizzes,
      averageScore,
      categoryPerformance,
      streakDays: calculateStreak(scoreHistory),
      strongAreas,
      improvementAreas,
      recentTrend
    };
  }, [scoreHistory]);

  const calculateStreak = (scores: ScoreEntry[]) => {
    if (scores.length === 0) return 0;
    
    const today = new Date();
    const dates = scores.map(s => new Date(s.date)).sort((a, b) => b.getTime() - a.getTime());
    
    let streak = 0;
    let currentDate = today;
    
    for (const date of dates) {
      const diffDays = Math.floor((currentDate.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
      if (diffDays <= 1) {
        streak++;
        currentDate = date;
      } else {
        break;
      }
    }
    
    return streak;
  };

  const chartData = Object.entries(analytics.categoryPerformance).map(([category, data]: [string, any]) => ({
    category: category.replace('-', ' '),
    score: Math.round(data.averageScore),
    attempts: data.attempts
  }));

  const pieData = chartData.map((item, index) => ({
    name: item.category,
    value: item.attempts,
    color: `hsl(${index * 60}, 70%, 50%)`
  }));

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-secondary/10 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Analytics Dashboard</h1>
            <p className="text-muted-foreground">Comprehensive analysis of your learning journey</p>
          </div>
          <button
            onClick={onClose}
            className="text-2xl hover:text-primary transition-colors"
          >
            ×
          </button>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-6 text-center bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
            <div className="text-3xl font-bold text-primary mb-2">{analytics.totalQuizzes}</div>
            <div className="text-sm text-muted-foreground">Total Quizzes</div>
          </Card>
          
          <Card className="p-6 text-center bg-gradient-to-br from-success/10 to-success/5 border-success/20">
            <div className="text-3xl font-bold text-success mb-2">{Math.round(analytics.averageScore)}%</div>
            <div className="text-sm text-muted-foreground">Average Score</div>
          </Card>
          
          <Card className="p-6 text-center bg-gradient-to-br from-secondary/10 to-secondary/5 border-secondary/20">
            <div className="text-3xl font-bold text-secondary mb-2">{analytics.streakDays}</div>
            <div className="text-sm text-muted-foreground">Day Streak</div>
          </Card>
          
          <Card className="p-6 text-center bg-gradient-to-br from-accent/10 to-accent/5 border-accent/20">
            <div className="text-3xl font-bold text-accent mb-2">{Object.keys(analytics.categoryPerformance).length}</div>
            <div className="text-sm text-muted-foreground">Categories Explored</div>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Performance by Category */}
          <Card className="p-6 bg-card/80 backdrop-blur-sm">
            <h3 className="text-xl font-semibold mb-4 text-foreground">Performance by Category</h3>
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="category" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Bar dataKey="score" fill="hsl(var(--primary))" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-64 text-muted-foreground">
                No data available yet. Take a quiz to see your analytics!
              </div>
            )}
          </Card>

          {/* Quiz Distribution */}
          <Card className="p-6 bg-card/80 backdrop-blur-sm">
            <h3 className="text-xl font-semibold mb-4 text-foreground">Quiz Distribution</h3>
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-64 text-muted-foreground">
                No quiz data available yet
              </div>
            )}
          </Card>
        </div>

        {/* Recent Trend */}
        {analytics.recentTrend.length > 0 && (
          <Card className="p-6 mb-8 bg-card/80 backdrop-blur-sm">
            <h3 className="text-xl font-semibold mb-4 text-foreground">Recent Performance Trend</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={analytics.recentTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="quiz" />
                <YAxis domain={[0, 100]} />
                <Tooltip labelFormatter={(value) => `Quiz ${value}`} />
                <Line type="monotone" dataKey="score" stroke="hsl(var(--primary))" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        )}

        {/* Insights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="p-6 bg-card/80 backdrop-blur-sm">
            <h3 className="text-xl font-semibold mb-4 text-success">🎯 Strong Areas</h3>
            {analytics.strongAreas.length > 0 ? (
              <div className="space-y-2">
                {analytics.strongAreas.map((area, index) => (
                  <Badge key={index} variant="secondary" className="mr-2 mb-2 bg-success/10 text-success border-success/20">
                    {area.replace('-', ' ')}
                  </Badge>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground">Take more quizzes to identify your strong areas!</p>
            )}
          </Card>

          <Card className="p-6 bg-card/80 backdrop-blur-sm">
            <h3 className="text-xl font-semibold mb-4 text-warning">📈 Areas for Improvement</h3>
            {analytics.improvementAreas.length > 0 ? (
              <div className="space-y-2">
                {analytics.improvementAreas.map((area, index) => (
                  <Badge key={index} variant="secondary" className="mr-2 mb-2 bg-warning/10 text-warning border-warning/20">
                    {area.replace('-', ' ')}
                  </Badge>
                ))}
                <p className="text-sm text-muted-foreground mt-4">
                  Focus on these areas to improve your overall performance
                </p>
              </div>
            ) : (
              <p className="text-muted-foreground">Great job! No areas need immediate improvement.</p>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;