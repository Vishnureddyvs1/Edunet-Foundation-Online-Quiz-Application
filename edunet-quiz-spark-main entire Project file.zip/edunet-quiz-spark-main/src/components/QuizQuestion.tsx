import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Question } from "@/data/questions";

interface QuizQuestionProps {
  question: Question;
  questionNumber: number;
  totalQuestions: number;
  onAnswer: (selectedAnswer: number, isCorrect: boolean) => void;
  onNext: () => void;
}

const QuizQuestion = ({ 
  question, 
  questionNumber, 
  totalQuestions, 
  onAnswer, 
  onNext 
}: QuizQuestionProps) => {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30);

  useEffect(() => {
    setSelectedAnswer(null);
    setShowFeedback(false);
    setTimeLeft(30);
  }, [question.id]);

  useEffect(() => {
    if (timeLeft > 0 && !showFeedback) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !showFeedback) {
      // Time's up - auto submit with no selection
      handleAnswerSubmit(null);
    }
  }, [timeLeft, showFeedback]);

  const handleAnswerSelect = (answerIndex: number) => {
    if (!showFeedback) {
      setSelectedAnswer(answerIndex);
    }
  };

  const handleAnswerSubmit = (answer: number | null) => {
    if (showFeedback) return;
    
    const isCorrect = answer === question.correctAnswer;
    setShowFeedback(true);
    onAnswer(answer || -1, isCorrect);
  };

  const handleNext = () => {
    onNext();
  };

  const progressPercentage = ((questionNumber - 1) / totalQuestions) * 100;
  const timerPercentage = (timeLeft / 30) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-secondary/10 flex items-center justify-center p-4">
      <div className="max-w-3xl w-full">
        {/* Progress Bar */}
        <div className="mb-8 quiz-fade-in">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-muted-foreground">
              Question {questionNumber} of {totalQuestions}
            </span>
            <span className="text-sm font-medium text-muted-foreground">
              Progress: {Math.round(progressPercentage)}%
            </span>
          </div>
          <Progress value={progressPercentage} className="h-2" />
        </div>

        {/* Timer */}
        <div className="mb-6 quiz-slide-in">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-muted-foreground">Time Remaining</span>
            <span className={`text-sm font-bold ${timeLeft <= 10 ? 'text-error timer-pulse' : 'text-primary'}`}>
              {timeLeft}s
            </span>
          </div>
          <Progress 
            value={timerPercentage} 
            className={`h-1 ${timeLeft <= 10 ? 'timer-pulse' : ''}`}
          />
        </div>

        {/* Question Card */}
        <Card className="p-8 mb-6 bg-card/90 backdrop-blur-sm border-primary/20 quiz-bounce">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8 leading-relaxed">
            {question.question}
          </h2>

          <div className="space-y-4">
            {question.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswerSelect(index)}
                className={`
                  w-full p-4 text-left rounded-lg border-2 transition-all duration-200 quiz-option
                  ${selectedAnswer === index && !showFeedback
                    ? 'border-primary bg-primary/10 shadow-md'
                    : showFeedback && index === question.correctAnswer
                    ? 'border-success bg-success/10 text-success-foreground correct'
                    : showFeedback && selectedAnswer === index && index !== question.correctAnswer
                    ? 'border-error bg-error/10 text-error-foreground incorrect'
                    : 'border-border bg-card hover:border-primary/50 hover:bg-primary/5'
                  }
                  ${showFeedback ? 'pointer-events-none' : ''}
                `}
              >
                <div className="flex items-center gap-3">
                  <div className={`
                    w-6 h-6 rounded-full border-2 flex items-center justify-center text-sm font-bold
                    ${selectedAnswer === index && !showFeedback
                      ? 'border-primary bg-primary text-primary-foreground'
                      : showFeedback && index === question.correctAnswer
                      ? 'border-success bg-success text-success-foreground'
                      : showFeedback && selectedAnswer === index && index !== question.correctAnswer
                      ? 'border-error bg-error text-error-foreground'
                      : 'border-muted-foreground'
                    }
                  `}>
                    {String.fromCharCode(65 + index)}
                  </div>
                  <span className="font-medium">{option}</span>
                </div>
              </button>
            ))}
          </div>

          {showFeedback && (
            <div className="mt-6 p-4 bg-muted/50 rounded-lg quiz-fade-in">
              <div className="flex items-start gap-3">
                <div className={`
                  w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm
                  ${selectedAnswer === question.correctAnswer ? 'bg-success' : 'bg-error'}
                `}>
                  {selectedAnswer === question.correctAnswer ? '✓' : '✗'}
                </div>
                <div>
                  <p className={`font-semibold mb-1 ${
                    selectedAnswer === question.correctAnswer ? 'text-success' : 'text-error'
                  }`}>
                    {selectedAnswer === question.correctAnswer ? 'Correct!' : 'Incorrect'}
                  </p>
                  <p className="text-muted-foreground">{question.explanation}</p>
                </div>
              </div>
            </div>
          )}
        </Card>

        {/* Action Buttons */}
        <div className="flex justify-between items-center">
          <div className="text-sm text-muted-foreground">
            {showFeedback ? 'Ready for next question?' : 'Select an answer to continue'}
          </div>
          
          <div className="flex gap-3">
            {!showFeedback && selectedAnswer !== null && (
              <Button 
                onClick={() => handleAnswerSubmit(selectedAnswer)}
                className="bg-primary hover:bg-primary-dark text-primary-foreground"
              >
                Submit Answer
              </Button>
            )}
            
            {showFeedback && (
              <Button 
                onClick={handleNext}
                className="bg-secondary hover:bg-secondary-dark text-secondary-foreground"
              >
                {questionNumber === totalQuestions ? 'View Results' : 'Next Question'} →
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuizQuestion;