import { useState, useCallback } from 'react';
import { enhancedQuestions, getRandomQuestions, QuizCategory } from '@/data/enhancedQuestions';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import QuizLanding from './QuizLanding';
import CategorySelector from './CategorySelector';
import QuizCreator from './QuizCreator';
import QuizQuestion from './QuizQuestion';
import QuizResults from './QuizResults';
import AnalyticsDashboard from './AnalyticsDashboard';

type QuizState = 'landing' | 'categories' | 'creator' | 'question' | 'results' | 'analytics';

interface ScoreEntry {
  name: string;
  score: number;
  total: number;
  date: string;
  percentage: number;
  category?: string;
  timeSpent?: number;
}

const QuizApp = () => {
  const [currentState, setCurrentState] = useState<QuizState>('landing');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>([]);
  const [currentQuestions, setCurrentQuestions] = useState(enhancedQuestions.slice(0, 10));
  const [selectedCategory, setSelectedCategory] = useState<QuizCategory | null>(null);
  const [quizStartTime, setQuizStartTime] = useState<number>(0);
  const [leaderboard, setLeaderboard] = useLocalStorage<ScoreEntry[]>('edunet-quiz-leaderboard', []);

  const currentQuestion = currentQuestions[currentQuestionIndex];
  const totalQuestions = currentQuestions.length;

  const startQuiz = useCallback((questions = enhancedQuestions.slice(0, 10)) => {
    setCurrentQuestions(questions);
    setCurrentState('question');
    setCurrentQuestionIndex(0);
    setScore(0);
    setUserAnswers([]);
    setQuizStartTime(Date.now());
  }, []);

  const selectCategory = useCallback((category: QuizCategory) => {
    setSelectedCategory(category);
    const categoryQuestions = getRandomQuestions(category.id, 10);
    startQuiz(categoryQuestions);
  }, [startQuiz]);

  const createCustomQuiz = useCallback((questions: any[]) => {
    setSelectedCategory(null);
    startQuiz(questions);
  }, [startQuiz]);

  const handleAnswer = useCallback((selectedAnswer: number, isCorrect: boolean) => {
    setUserAnswers(prev => [...prev, selectedAnswer]);
    if (isCorrect) {
      setScore(prev => prev + 1);
    }
  }, []);

  const handleNext = useCallback(() => {
    if (currentQuestionIndex < totalQuestions - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setCurrentState('results');
    }
  }, [currentQuestionIndex, totalQuestions]);

  const saveScore = useCallback((playerName: string) => {
    const timeSpent = Math.round((Date.now() - quizStartTime) / 1000 / 60); // in minutes
    const newScore: ScoreEntry = {
      name: playerName,
      score,
      total: totalQuestions,
      date: new Date().toLocaleDateString(),
      percentage: Math.round((score / totalQuestions) * 100),
      category: selectedCategory?.id || 'custom',
      timeSpent
    };

    setLeaderboard(prev => {
      const updated = [...prev, newScore];
      // Sort by percentage (desc), then by score (desc), then by date (desc)
      return updated
        .sort((a, b) => {
          if (b.percentage !== a.percentage) return b.percentage - a.percentage;
          if (b.score !== a.score) return b.score - a.score;
          return new Date(b.date).getTime() - new Date(a.date).getTime();
        })
        .slice(0, 20); // Keep top 20 scores for better analytics
    });
  }, [score, totalQuestions, selectedCategory, quizStartTime, setLeaderboard]);

  const restartQuiz = useCallback(() => {
    setCurrentState('landing');
    setCurrentQuestionIndex(0);
    setScore(0);
    setUserAnswers([]);
  }, []);

  switch (currentState) {
    case 'landing':
      return (
        <QuizLanding 
          onStartQuiz={() => startQuiz()}
          onSelectCategory={() => setCurrentState('categories')}
          onViewAnalytics={() => setCurrentState('analytics')}
          leaderboard={leaderboard}
        />
      );

    case 'categories':
      return (
        <CategorySelector
          onSelectCategory={selectCategory}
          onCreateCustomQuiz={() => setCurrentState('creator')}
        />
      );

    case 'creator':
      return (
        <QuizCreator
          onCreateQuiz={createCustomQuiz}
          onBack={() => setCurrentState('categories')}
        />
      );
    
    case 'question':
      return (
        <QuizQuestion
          question={currentQuestion}
          questionNumber={currentQuestionIndex + 1}
          totalQuestions={totalQuestions}
          onAnswer={handleAnswer}
          onNext={handleNext}
        />
      );
    
    case 'results':
      return (
        <QuizResults
          score={score}
          totalQuestions={totalQuestions}
          onRestart={restartQuiz}
          onSaveScore={saveScore}
        />
      );

    case 'analytics':
      return (
        <AnalyticsDashboard
          onClose={() => setCurrentState('landing')}
        />
      );
    
    default:
      return null;
  }
};

export default QuizApp;