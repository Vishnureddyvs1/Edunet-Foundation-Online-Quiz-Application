export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  tags: string[];
}

export interface QuizCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  questionCount: number;
}

export const quizCategories: QuizCategory[] = [
  {
    id: 'web-dev',
    name: 'Web Development',
    description: 'HTML, CSS, JavaScript, React, and modern web technologies',
    icon: '🌐',
    color: 'from-blue-500 to-purple-500',
    questionCount: 15
  },
  {
    id: 'cybersecurity',
    name: 'Cybersecurity',
    description: 'Network security, ethical hacking, and data protection',
    icon: '🛡️',
    color: 'from-red-500 to-orange-500',
    questionCount: 20
  },
  {
    id: 'software-engineering',
    name: 'Software Engineering',
    description: 'Programming principles, design patterns, and methodologies',
    icon: '⚙️',
    color: 'from-green-500 to-teal-500',
    questionCount: 18
  },
  {
    id: 'data-science',
    name: 'Data Science & AI',
    description: 'Machine learning, data analysis, and artificial intelligence',
    icon: '🤖',
    color: 'from-purple-500 to-pink-500',
    questionCount: 16
  },
  {
    id: 'cloud-computing',
    name: 'Cloud Computing',
    description: 'AWS, Azure, DevOps, and cloud architectures',
    icon: '☁️',
    color: 'from-cyan-500 to-blue-500',
    questionCount: 14
  },
  {
    id: 'mobile-dev',
    name: 'Mobile Development',
    description: 'iOS, Android, React Native, and mobile technologies',
    icon: '📱',
    color: 'from-indigo-500 to-purple-500',
    questionCount: 12
  }
];

export const enhancedQuestions: Question[] = [
  // Web Development Questions
  {
    id: 1,
    question: "What is the primary purpose of the Edunet Foundation?",
    options: ["Entertainment and gaming", "Education and skill development", "Sports and recreation", "Healthcare services"],
    correctAnswer: 1,
    explanation: "Edunet Foundation focuses on providing quality education and skill development opportunities.",
    category: 'web-dev',
    difficulty: 'easy',
    tags: ['foundation', 'education']
  },
  {
    id: 2,
    question: "Which CSS property is used to create flexbox layouts?",
    options: ["display: flex", "flex-direction", "justify-content", "align-items"],
    correctAnswer: 0,
    explanation: "The display: flex property is the fundamental property that enables flexbox layout.",
    category: 'web-dev',
    difficulty: 'medium',
    tags: ['css', 'flexbox', 'layout']
  },
  {
    id: 3,
    question: "What is the Virtual DOM in React?",
    options: ["A real DOM element", "A JavaScript representation of the DOM", "A browser API", "A React component"],
    correctAnswer: 1,
    explanation: "The Virtual DOM is a JavaScript representation of the actual DOM that React uses for efficient updates.",
    category: 'web-dev',
    difficulty: 'medium',
    tags: ['react', 'virtual-dom', 'javascript']
  },

  // Cybersecurity Questions
  {
    id: 4,
    question: "What does SQL injection attack target?",
    options: ["Network protocols", "Database queries", "File systems", "User interfaces"],
    correctAnswer: 1,
    explanation: "SQL injection attacks target database queries by inserting malicious SQL code.",
    category: 'cybersecurity',
    difficulty: 'medium',
    tags: ['sql-injection', 'database', 'security']
  },
  {
    id: 5,
    question: "Which encryption algorithm is considered most secure for current standards?",
    options: ["DES", "MD5", "AES-256", "SHA-1"],
    correctAnswer: 2,
    explanation: "AES-256 is currently considered the gold standard for symmetric encryption.",
    category: 'cybersecurity',
    difficulty: 'hard',
    tags: ['encryption', 'aes', 'cryptography']
  },
  {
    id: 6,
    question: "What is the first step in ethical hacking?",
    options: ["Exploitation", "Reconnaissance", "Privilege escalation", "Covering tracks"],
    correctAnswer: 1,
    explanation: "Reconnaissance is the first phase where information about the target is gathered.",
    category: 'cybersecurity',
    difficulty: 'medium',
    tags: ['ethical-hacking', 'reconnaissance', 'penetration-testing']
  },

  // Software Engineering Questions
  {
    id: 7,
    question: "Which design pattern ensures a class has only one instance?",
    options: ["Factory", "Observer", "Singleton", "Strategy"],
    correctAnswer: 2,
    explanation: "The Singleton pattern ensures that a class has only one instance and provides global access to it.",
    category: 'software-engineering',
    difficulty: 'medium',
    tags: ['design-patterns', 'singleton', 'oop']
  },
  {
    id: 8,
    question: "What does SOLID stand for in software engineering?",
    options: ["Software Object-Oriented Language Integration Design", "Single responsibility, Open-closed, Liskov substitution, Interface segregation, Dependency inversion", "Systematic Object Logic Implementation Design", "Software Operations and Logic Integration Development"],
    correctAnswer: 1,
    explanation: "SOLID represents five key principles of object-oriented programming and design.",
    category: 'software-engineering',
    difficulty: 'hard',
    tags: ['solid', 'principles', 'oop']
  },

  // Data Science & AI Questions
  {
    id: 9,
    question: "What is the main difference between supervised and unsupervised learning?",
    options: ["Supervised uses labeled data", "Unsupervised is faster", "Supervised is more accurate", "There is no difference"],
    correctAnswer: 0,
    explanation: "Supervised learning uses labeled training data, while unsupervised learning finds patterns in unlabeled data.",
    category: 'data-science',
    difficulty: 'medium',
    tags: ['machine-learning', 'supervised', 'unsupervised']
  },
  {
    id: 10,
    question: "Which algorithm is commonly used for classification problems?",
    options: ["K-means", "Linear Regression", "Random Forest", "K-nearest neighbors"],
    correctAnswer: 2,
    explanation: "Random Forest is a popular ensemble method used for both classification and regression problems.",
    category: 'data-science',
    difficulty: 'medium',
    tags: ['classification', 'random-forest', 'algorithms']
  },

  // Cloud Computing Questions
  {
    id: 11,
    question: "What does IaaS stand for in cloud computing?",
    options: ["Internet as a Service", "Infrastructure as a Service", "Integration as a Service", "Information as a Service"],
    correctAnswer: 1,
    explanation: "IaaS (Infrastructure as a Service) provides virtualized computing infrastructure over the internet.",
    category: 'cloud-computing',
    difficulty: 'easy',
    tags: ['iaas', 'cloud-services', 'infrastructure']
  },
  {
    id: 12,
    question: "Which AWS service is used for object storage?",
    options: ["EC2", "RDS", "S3", "Lambda"],
    correctAnswer: 2,
    explanation: "Amazon S3 (Simple Storage Service) is AWS's object storage service.",
    category: 'cloud-computing',
    difficulty: 'easy',
    tags: ['aws', 's3', 'storage']
  },

  // Mobile Development Questions
  {
    id: 13,
    question: "What is React Native primarily used for?",
    options: ["Web development", "Cross-platform mobile development", "Desktop applications", "Server-side development"],
    correctAnswer: 1,
    explanation: "React Native is a framework for building cross-platform mobile applications using React.",
    category: 'mobile-dev',
    difficulty: 'easy',
    tags: ['react-native', 'mobile', 'cross-platform']
  },
  {
    id: 14,
    question: "Which programming language is used for iOS app development?",
    options: ["Java", "Kotlin", "Swift", "C#"],
    correctAnswer: 2,
    explanation: "Swift is Apple's programming language for iOS and macOS app development.",
    category: 'mobile-dev',
    difficulty: 'easy',
    tags: ['ios', 'swift', 'apple']
  },

  // Additional questions for variety
  {
    id: 15,
    question: "What is the purpose of version control systems like Git?",
    options: ["To compress files", "To track changes and collaborate on code", "To run automated tests", "To deploy applications"],
    correctAnswer: 1,
    explanation: "Version control systems help track code changes, maintain history, and enable team collaboration.",
    category: 'software-engineering',
    difficulty: 'easy',
    tags: ['git', 'version-control', 'collaboration']
  }
];

export const getQuestionsByCategory = (categoryId: string): Question[] => {
  return enhancedQuestions.filter(q => q.category === categoryId);
};

export const getRandomQuestions = (categoryId: string, count: number = 10): Question[] => {
  const categoryQuestions = getQuestionsByCategory(categoryId);
  const shuffled = [...categoryQuestions].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(count, shuffled.length));
};

export const getMotivationalMessage = (score: number, total: number): string => {
  const percentage = (score / total) * 100;
  
  if (percentage >= 90) {
    return "🎉 Outstanding! You're a true learning champion!";
  } else if (percentage >= 80) {
    return "🌟 Excellent work! You've mastered the fundamentals!";
  } else if (percentage >= 70) {
    return "👏 Great job! You're well on your way to success!";
  } else if (percentage >= 60) {
    return "👍 Good effort! Keep practicing and you'll improve!";
  } else if (percentage >= 50) {
    return "💪 You're making progress! Don't give up, keep learning!";
  } else {
    return "🚀 Every expert was once a beginner. Keep going!";
  }
};

export interface QuizAnalytics {
  totalQuizzesTaken: number;
  averageScore: number;
  categoryPerformance: { [key: string]: { attempts: number; averageScore: number } };
  timeSpentLearning: number; // in minutes
  streakDays: number;
  lastQuizDate: string;
  strongAreas: string[];
  improvementAreas: string[];
}