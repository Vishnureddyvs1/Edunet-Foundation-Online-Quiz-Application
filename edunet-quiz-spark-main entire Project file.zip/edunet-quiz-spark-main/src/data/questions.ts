export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export const quizQuestions: Question[] = [
  {
    id: 1,
    question: "What is the primary purpose of the Edunet Foundation?",
    options: [
      "Entertainment and gaming",
      "Education and skill development",
      "Sports and recreation",
      "Healthcare services"
    ],
    correctAnswer: 1,
    explanation: "Edunet Foundation focuses on providing quality education and skill development opportunities."
  },
  {
    id: 2,
    question: "Which programming language is known for its simplicity and readability?",
    options: [
      "Assembly",
      "C++",
      "Python",
      "Machine Code"
    ],
    correctAnswer: 2,
    explanation: "Python is renowned for its clean syntax and readability, making it perfect for beginners."
  },
  {
    id: 3,
    question: "What does HTML stand for?",
    options: [
      "High Tech Modern Language",
      "HyperText Markup Language",
      "Home Tool Markup Language",
      "Hyperlink and Text Markup Language"
    ],
    correctAnswer: 1,
    explanation: "HTML stands for HyperText Markup Language, the standard markup language for web pages."
  },
  {
    id: 4,
    question: "In which year was JavaScript first released?",
    options: [
      "1993",
      "1995",
      "1997",
      "1999"
    ],
    correctAnswer: 1,
    explanation: "JavaScript was first released in 1995 by Brendan Eich at Netscape."
  },
  {
    id: 5,
    question: "What is the main advantage of responsive web design?",
    options: [
      "Faster loading times",
      "Better SEO ranking",
      "Optimal viewing across all devices",
      "Reduced development costs"
    ],
    correctAnswer: 2,
    explanation: "Responsive design ensures websites adapt to different screen sizes, providing optimal viewing experience on all devices."
  },
  {
    id: 6,
    question: "Which CSS property is used to create animations?",
    options: [
      "transition",
      "animation",
      "transform",
      "All of the above"
    ],
    correctAnswer: 3,
    explanation: "All three properties - transition, animation, and transform - can be used to create different types of animations in CSS."
  },
  {
    id: 7,
    question: "What is the purpose of version control systems like Git?",
    options: [
      "To compress files",
      "To track changes and collaborate on code",
      "To run automated tests",
      "To deploy applications"
    ],
    correctAnswer: 1,
    explanation: "Version control systems help track code changes, maintain history, and enable team collaboration."
  },
  {
    id: 8,
    question: "Which of the following is NOT a JavaScript framework?",
    options: [
      "React",
      "Angular",
      "Django",
      "Vue.js"
    ],
    correctAnswer: 2,
    explanation: "Django is a Python web framework, while React, Angular, and Vue.js are JavaScript frameworks."
  },
  {
    id: 9,
    question: "What does API stand for?",
    options: [
      "Application Programming Interface",
      "Advanced Programming Integration",
      "Automated Program Interaction",
      "Application Process Integration"
    ],
    correctAnswer: 0,
    explanation: "API stands for Application Programming Interface, allowing different software applications to communicate."
  },
  {
    id: 10,
    question: "Which is the most important principle of clean code?",
    options: [
      "Complex algorithms",
      "Readability and maintainability",
      "Shortest possible code",
      "Using advanced features"
    ],
    correctAnswer: 1,
    explanation: "Clean code prioritizes readability and maintainability, making it easier for others to understand and modify."
  }
];

export const getMotivationalMessage = (score: number, total: number): string => {
  const percentage = (score / total) * 100;
  
  if (percentage >= 90) {
    return "🎉 Outstanding! You're a true learning champion!";
  } else if (percentage >= 80) {
    return "🌟 Excellent work! You've mastered the fundamentals!";
  } else if (percentage >= 70) {
    return "👏 Great job! You're well on your way to success!";
  } else if (percentage >= 60) {
    return "👍 Good effort! Keep practicing and you'll improve!";
  } else if (percentage >= 50) {
    return "💪 You're making progress! Don't give up, keep learning!";
  } else {
    return "🚀 Every expert was once a beginner. Keep going!";
  }
};